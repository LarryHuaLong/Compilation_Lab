#ifndef foo_h
#define foo_h

#ifndef NO_RCS_ID
static const char *foo_h_RcsId = "$Id: foo.h,v 1.3 1998/05/06 14:36:40 frodo Exp $";
#endif  /* NO_RCS_ID */

/*****************************************************************************
 * foo.h --
 *	This file contains the definition for the 'foo' class.  This class
 *	will read an expression from a file and calculate a result.
 *
 * Author --
 *	David Fletcher.
 *
 * Date --
 *	Wed Dec  3 12:11:04 1997.
 *
 * Design --
 *	Obviously, the grammar is quite simple, and more work should be done
 *	to stress the system.  But, this should be enough to test the whole
 *	schmeer.
 *
 *****************************************************************************
 */

/******************   # d e f i n e    S t a t e m e n t s   *****************/

/***************   I n c l u d e d    D e p e n d e n c i e s   **************/
#include <Parser.h>

#undef	yyFlexLexer
#define	yyFlexLexer fooFlexLexer

#include <FlexLexer.h>

/**************    T y p e d e f ' e d    V a l u e s    *********************/

/***************    E n u m e r a t e d    T y p e s    **********************/

/*****************   C l a s s e s / S t r u c t u r e s   *******************/

/*----------------------------------------------------------------------------
 * foo --
 *	A class that implements a simple calculator, reading expressions
 *	from a file.
 *
 *----------------------------------------------------------------------------
 */
class foo : public Parser
{
  /*--------------   P u b l i c   I n t e r f a c e    ---------------*/
 public:
  foo();

  ~foo();

  int				Read(const char*, int);
  int				Read(int);
  
  double			GetResult() const;
  void				SetResult(double);

  /*----------   O v e r l o a d e d   O p e r a t o r s    -----------*/
 public:

  /*-------   I n t e r n a l / I m p l e m e n t a t i o n    --------*/
 protected:
  //-------------------------------------------------------
  // The lexer can call the yylval() function to pass
  // back 'look-ahead' information to the parser.
  //-------------------------------------------------------
  virtual void			yylval(double d);

  //-------------------------------------------------------
  // The TableInit(), TranslateSymbol(), and
  // DoReduceActions() functions are all emitted by bison,
  // and override the pure virtual functions defined in
  // the Parser base class.
  //-------------------------------------------------------
  virtual void			TableInit();
  virtual int			TranslateSymbol(int iSymbol);
  virtual Parser::Action	DoReduceActions(StateType NextState,
						char* pValueStack,
						char* pDefaultValue);

  //-------------------------------------------------------
  // The yylex() function is called when new tokens are
  // needed.  Normally, flex will be used, though this isn't
  // necessary.
  //-------------------------------------------------------
  virtual int			yylex();

  //-------------------------------------------------------
  // The yyerror() function is called when an error message
  // occurs.
  //-------------------------------------------------------
  virtual void			yyerror(const char*);

 private:
  //-------------------------------------------------------
  // Declared but not defined, to prevent the compiler from
  // generating these for us.
  //-------------------------------------------------------
  foo(const foo&);
  foo& operator=(const foo&);

  /*--------------------------   D a t a    ---------------------------*/
 protected:
  //-------------------------------------------------------
  // For this example, the lexer is a flex-generated,
  // C++-based, object-oriented lexer.  It's not necessary
  // to use flex, but it does tend to simplify things a
  // bit.  Note that the lexer is a friend to the parser
  // so that the lexer can invoke the yylval() function(s)
  // within this class.
  //-------------------------------------------------------
  fooFlexLexer		l;

  double		dResult; // The running tally...

 private:

  /*-----------------------   F r i e n d s    ------------------------*/
  friend class fooFlexLexer;
};


/**********************   I n l i n e    M e t h o d s   *********************/

/**********************   E x p o r t e d    I t e m s   *********************/

#endif 	/* foo_h */
