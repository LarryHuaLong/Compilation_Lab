#ifndef Parser_h
#define Parser_h

#ifndef NO_RCS_ID
static const char *Parser_h_RcsId = "$Id: Parser.h,v 1.4 1998/04/21 21:15:41 frodo Exp $";
#endif  /* NO_RCS_ID */

/*****************************************************************************
 * Parser.h --
 *	Definition of the base Parser class.
 *
 * Author --
 *	Richard Stallman.  Modifications by David Fletcher.
 *
 * Date --
 *	Fri Apr 17 15:28:50 1998.
 *
 * Design --
 *	There are a couple of motivations for re-working the parser:
 *		- Casting the parser as a class allows us to remove the
 *		  need for the global variables that so often accompany a
 *		  yacc-compatible parser.  Bison does provide the machinery
 *		  to implement a 'pure parser', which does eliminate global
 *		  variables, so implementing the parser as a class
 *		  isn't strictly necessary.
 *
 *		- Having the parser be a class allows us to add member
 *		  functions that are particular to a parser.  For object-
 *		  oriented systems, this yields a clean, extensible design.
 *
 *	The basic approach is that there is an abstract base class, called Parser,
 *	that implements the generic parsing machinery.  This base class is similar
 *	to---derived from, actually---the simple parser provided with bison.
 *	The base class provides the parsing machinery, but lacks the information
 *	needed to parse a specific grammar.  For this, a developer will create a
 *	class derived from the Parser base class, and part of the derived class
 *	consists of functions produced by bison; these functions contain
 *	the specialisations needed to recognise a particular grammar.
 *
 *	N.B.: While all of this works reasonably well with C++, this
 *	implementation still lacks some of the 'smarts' needed to make it
 *	truly work well.  In particular, the Parser base class is unaware
 *	of the data type of the items kept on the value stack.  During a
 *	shift operation, a reduce operation, or when the value stack is
 *	resized, items on the value stack are simply copied via memcpy().
 *	This is not correct, though it's benign if only pointers and numerical
 *	types are used.  What should happen is that the items added to or
 *	removed from the value stack should be handled in such a way that
 *	the object's constructor, destructor, or assignment operator are
 *	invoked.  This would allow, say, string objects to be placed on the
 *	value stack.  Unfortunately, the current implementation requires that
 *	pointers to a string (or similar) object be placed on the value stack.
 *
 *	The changes needed to implement this are not difficult and are reasonably
 *	well contained.  Search for pValueStackCurrent to see where the
 *	stack is manipulated; also, the GrowStacks() method needs to be
 *	modified.  While these changes are relatively straightfoward,
 *	I've not made them yet.
 *						David Fletcher
 *						20 April, 1998
 *
 *****************************************************************************
 */

/******************   # d e f i n e    S t a t e m e n t s   *****************/
#define yyerrok		(iNumErrors = 0)
#define yyclearin	(iLookAheadSymbol = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0

#define YYACCEPT	return eAccept
#define YYABORT 	return eAbort
#define YYERROR		return eNewError

/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go. */
#define YYFAIL		return eError

#define YYRECOVERING()  (!!iNumErrors)

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

#if !defined(Parser_EXPORT)
# define Parser_EXPORT
#endif

/***************   I n c l u d e d    D e p e n d e n c i e s   **************/

/**************    T y p e d e f ' e d    V a l u e s    *********************/

/***************    E n u m e r a t e d    T y p e s    **********************/

/*****************   C l a s s e s / S t r u c t u r e s   *******************/

/*----------------------------------------------------------------------------
 * Parser --
 *	This is an abstract base class that implements the generic machinery
 *	found in a bison-oriented parser.  It is directly derived from the
 *	parser described in the bison.simple (that comes with bison).
 *
 *	See the comments above for more information.
 *
 *----------------------------------------------------------------------------
 */
class  Parser_EXPORT  Parser
{
  /*--------------   P u b l i c   I n t e r f a c e    ---------------*/
 public:
  //-------------------------------------------------------
  // Argh.  VC++ 5.0 requires that this enum be public,
  // because there are functions that return this value.
  // This is clearly a bug in the compiler, but hey,
  // what else can we do but capitulate.
  //-------------------------------------------------------
  enum Action
    {
      eAccept, eAbort, eNewState, eShift, eReduce,
      eNewError, eError, ePopError, eHandleError
    };


  /*----------   O v e r l o a d e d   O p e r a t o r s    -----------*/
 public:

  /*-------   I n t e r n a l / I m p l e m e n t a t i o n    --------*/
 protected:
  typedef int	StateType;


  Parser();
  virtual ~Parser();

  unsigned int		Parse(int iDebugArg = 0);

  //-------------------------------------------------------
  // These must be overriden in the derived class.  The
  // 'parser-gen' script will define all of these functions,
  // except for the yylex() method.  Most likely, the
  // yylex() method will invoke some lexer (generated by
  // flex, perhaps, or written by a developer).
  // 
  // The developer is responsible for calling the TableInit()
  // method within the constructor of the derived class.
  //
  // The default implementation of yyerror() performs no
  // actions; classes derived from Parser should define
  // yyerror() to do something meaningful.
  //-------------------------------------------------------
  virtual void		TableInit() = 0;
  virtual int		TranslateSymbol(int iSymbol) = 0;
  virtual Action	DoReduceActions(StateType NextState,
					char* pValueStack,
					char* pDefaultValue) = 0;
  virtual int		yylex() = 0;

  virtual void		yyerror(const char*);

  //-------------------------------------------------------
  // Derived classes are likely to provide functions that
  // can manipulate the look-ahead value; the GetLookAheadVal()
  // function can be used to return the memory location of
  // the look-ahead value.
  //-------------------------------------------------------
  virtual char*		GetLookAheadVal();

  //-------------------------------------------------------
  // The Init(), CreateStacks(), and GrowStacks() methods
  // can be overridden, should the need arise.  The default
  // behaviour of the Message() and ShowValue() methods is
  // to print information to stdout using stdio, or to cerr
  // using iostreams, or to do nothing, depending on how
  // the WANT_STDIO and WANT_IOSTREAMS pre-processor variables
  // are defined.  These can be overridden by derived classes
  // to effect other behaviours.
  //-------------------------------------------------------
  virtual void		Init();
  virtual void		CreateStacks();
  virtual void		GrowStacks();

  virtual void		Message(const char*);
  virtual void		Message(const char*, unsigned int);
  virtual void		Message(const char*, int, const char*);
  virtual void		Message(const char*, int, short);
  virtual void		Message(const char*, const char*);

  virtual void		ShowValue(int iLookAheadSymbol, const char* LookAheadValue);

  //-------------------------------------------------------
  // These functions implement the core of the (generic)
  // parser.  It's unlikely that these will need to be re-defined,
  // so that have not been made virtual (why pay for the
  // performance if you don't need the extra flexibility?).
  //-------------------------------------------------------
  Action		NewState();
  Action		Shift();
  Action		Reduce();
  Action		NewError();
  Action		ActionError();
  Action		ErrorPop();
  Action		HandleError();
  
  
 private:
  //-------------------------------------------------------
  // The copy constructor and assignment operator are declared
  // but not defined, since there is no way to make one
  // Parser be like another.
  //
  // TODO: It may be desirable to remove this limitation;
  // in order to do this, stack-copying routines, etc, will
  // have to be added to the Parser class.
  //-------------------------------------------------------
  Parser(const Parser&);
  Parser& operator=(const Parser&);

  /*--------------------------   D a t a    ---------------------------*/
 protected:

  //-------------------------------------------------------
  // Errors: total encountered, and the number during the
  // portion of the parse.
  //-------------------------------------------------------
  unsigned int		uiNumErrors;
  unsigned int		uiTotalNumErrors;
  unsigned int		uiDebugOn;

  //-------------------------------------------------------
  // Lookahead symbol and value.  The value that comes
  // from the lexer is a 'raw' value and needs to be
  // translated to a form usable by bison ---
  // iTranslatedSymbol holds this translated value.
  //-------------------------------------------------------
  int			iLookAheadSymbol;
  int			iTranslatedSymbol;

  char*			pLookAheadValue;

  //-------------------------------------------------------
  // Current/next state.
  //-------------------------------------------------------
  StateType	State;
  StateType	NextState;

  //-------------------------------------------------------
  // State and value stacks.
  //-------------------------------------------------------
  unsigned int		uiStackSize;
  unsigned int		uiStackNumEntries;

  StateType*		pStateStackCurrent;
  StateType*		pStateStackBase;

  unsigned int		uiValueSize;
  char*			pValueStackCurrent;
  char*			pValueStackBase;

  //-------------------------------------------------------
  // Bison generates a number of tables for any given grammar.
  // Since the base class can't know about these particular
  // tables, the Parse() method is written to use 'generic'
  // pointers to the tables.  The derived class's TableInit()
  // function is responsible for setting the pointers to
  // the appropriate variable.  The original names of the
  // the variable holding the table, a brief description
  // of the table, and the alternate name are all defined
  // below...
  //-------------------------------------------------------

  // yyprhs[r] = index in yyrhs of first item for rule r.
  // const short yyprhs[];
  const short* pFirstItemIndexTbl;

  // yyrhs = vector of items of all rules.
  // const short yyrhs[];
  const short* pRuleItemsTbl;

  // yyrline = vector of line-numbers of all rules.
  // For yydebug printouts.
  // const short yyrline[];
  const short* pRuleLineInfoTbl;
  
  // ** yytname = vector of string-names indexed by
  // bison token number.
  // const char * const yytname[];
  const char** pTokenNameTbl;

  // yyr1[r] = symbol number of symbol that rule r derives.
  // const short yyr1[];
  const short* pRuleDerivesTbl;
  

  // yyr2[r] = number of symbols composing right hand
  // side of rule r.
  // const short yyr2[];
  const short* pLengthRhsTbl;

  // yydefact[s] = default rule to reduce with in state s,
  // when yytable doesn't specify something else to do.
  // Zero means the default is an error.
  // const short yydefact[];
  const short* pDefaultRuleTbl;

  // yydefgoto[i] = default state to go to after a reduction of a rule that
  // generates variable ntokens + i, except when yytable
  // specifies something else to do.
  // const short yydefgoto[];
  const short* pDefaultGotoTbl;

  // yypact[s] = index in yytable of the portion describing state s.
  // The lookahead token's type is used to index that portion
  // to find out what to do.
  //
  // If the value in yytable is positive,
  // we shift the token and go to that state.
  //
  // If the value is negative, it is minus a rule number to reduce by.
  //
  // If the value is zero, the default action from yydefact[s] is used.
  // const short yypact[];
  const short* pShiftOrReduceTbl;

  // yypgoto[i] = the index in yytable of the portion describing 
  // what to do after reducing a rule that derives variable i + ntokens.
  // This portion is indexed by the parser state number, s,
  // as of before the text for this nonterminal was read.
  // The value from yytable is the state to go to if 
  // the corresponding value in yycheck is s.
  // const short yypgoto[];
  const short* pShiftOrReduceGotoTbl;

  // yytable = a vector filled with portions for different uses,
  // found via yypact and yypgoto.
  // const short yytable[];
  const short* pMiscTbl;

  // yycheck = a vector indexed in parallel with yytable.
  // It indicates, in a roundabout way, the bounds of the
  // portion you are trying to examine.
  // 
  // Suppose that the portion of yytable starts at index p
  // and the index to be examined within the portion is i.
  // Then if yycheck[p+i] != i, i is outside the bounds
  // of what is actually allocated, and the default
  // (from yydefact or yydefgoto) should be used.
  // Otherwise, yytable[p+i] should be used.
  // const short yycheck[];
  const short* pBoundsTbl;
  
  // YYLAST = the last (biggest) state
  StateType LastState;

  // YYFINAL = the state number of the termination state.
  StateType TerminationState;

  // YYFLAG = most negative short int.  Used to flag ??
  StateType FlagState;

  // YYNTBASE = ntokens. (same as YYNTOKENS).
  unsigned int uiNumTokens;

 private:

  /*-----------------------   F r i e n d s    ------------------------*/
};

/**********************   I n l i n e    M e t h o d s   *********************/

/**********************   E x p o r t e d    I t e m s   *********************/

#endif 	/* Parser_h */
