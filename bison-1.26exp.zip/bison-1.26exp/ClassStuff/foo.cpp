#ifndef NO_RCS_ID
static const char *foo_cpp_RcsId = "$Id: foo.cpp,v 1.3 1998/05/06 14:36:40 frodo Exp $";
#endif  /* NO_RCS_ID */

/*****************************************************************************
 * foo.cpp --
 *	Implementation of the 'foo' calculator class.
 *
 * Author --
 *	David Fletcher.
 *
 * Date --
 *	Wed Dec  3 12:15:41 1997.
 *
 * Design --
 *	Most of the 'smarts' for the class are defined in the file containing
 *	the grammar.  The remainder of this class is quite simple...
 *
 *****************************************************************************
 */

/******************   # d e f i n e    S t a t e m e n t s   *****************/

/************   I n c l u d e d    I n f o r m a t i o n   *******************/
#include <fstream.h>

#include "foo.h"
#include "foo.tab.h"

/**************    T y p e d e f ' e d    V a l u e s    *********************/

/***************    E n u m e r a t e d    T y p e s    **********************/

/*****************   C l a s s e s / S t r u c t u r e s   *******************/

/**********   O t h e r    E x t e r n a l    V a l u e s   ******************/

/**********   L o c a l l y    G l o b a l    V a l u e s   ******************/

/************************   T H E    C O D E   *******************************/

/*----------------------------------------------------------------------------
 * foo::foo()
 *	Constructor for the foo class.
 *
 * Design --
 *	Make sure that we call the TableInit() function, or else the
 *	tables used during the parsing phase won't be initialised.
 *	Also, tell the lexer (that is embedded within this class) that it
 *	belongs to this class.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
foo::foo()
  : Parser(), l(), dResult(0.0)
{
  TableInit();

  l.set_parser(this);
}

/*----------------------------------------------------------------------------
 * foo::~foo()
 *	Destructor for the foo class.
 *
 * Design --
 *	Not much to do --- the base class handles most everything.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
foo::~foo()
{
}

/*----------------------------------------------------------------------------
 * int foo::Read(const char* pcInputFile, int iDebug)
 * int foo::Read(int iDebug)
 *
 *	Open a file and read it.  If a file name was provided then read from
 *	cin.
 *
 * Return Value --
 *	The number of errors encountered during the parsing operating is
 *	returned.
 *
 * Design --
 *	Open the file (if necessary), then tell the lexer to read from
 *	that file (or from cin).  Then, invoke the parser.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
int
foo::Read(const char* pcInputFile, int iDebug)
{
  ifstream in(pcInputFile);

  if (!in)
    {
      cerr << "foo::Read(" << pcInputFile << ", " << iDebug <<") - couldn't open file.\n";
      return -1;
    }

  l.switch_streams(&in, &cout);

  int iResult = Parse(iDebug == 0 ? 0 : 1);

  return iResult;
}

int
foo::Read(int iDebug)
{
  l.switch_streams(&cin, &cout);

  int iResult = Parse(iDebug == 0 ? 0 : 1);

  return iResult;
}

/*----------------------------------------------------------------------------
 * int
 * foo::yylex()
 *	This function is responsible for getting the next token from the
 *	file.
 *
 * Return Value --
 *	An integer value corresponding to the token is returned.
 *
 * Design --
 *	We abdicate and let the flex-generated lexer do all of the work.
 *	If there is a value to be associated with the token returned by
 *	the flex-generated lexer, then the lexer is responsible is responsible
 *	for returning this 'out of bounds' via the yylval() function(s).
 *
 *	N.B. The functions don't have to be called yylval --- in fact, there
 *	isn't any restriction on the function name --- but I've used this
 *	name so that folks familiar with yacc/bison won't be confused.
 *
 * Side effects --
 *	None (not counting any calls to yylval(), etc).
 *----------------------------------------------------------------------------
 */
int
foo::yylex()
{
  return l.yylex();
}

/*----------------------------------------------------------------------------
 * void
 * foo::yyerror(const char* pcMessage)
 *	This function is called when an error is encountered.
 *
 * Return Value --
 *	Void.
 *
 * Design --
 *	We simply print the error message and return.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
void
foo::yyerror(const char* pcMessage)
{
  cerr << "foo: error \"" << pcMessage << "\".\n";
}

/*----------------------------------------------------------------------------
 * double foo::GetResult() const
 * void   foo::SetResult(double dResult)
 *
 *	These functions can be used to get/set the 'result' which is
 *	a double value.
 *
 * Return Value --
 *	Void.
 *
 * Design --
 *	Simple.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
double
foo::GetResult() const
{
  return dResult;
}

void
foo::SetResult(double dResult)
{
  this->dResult = dResult;
}

/*----------------------------------------------------------------------------
 * void
 * foo::yylval(double d)
 *	This function is called by the lexer in order to associate a value
 *	with a particular token.
 *
 * Return Value --
 *	Void.
 *
 * Design --
 *	We get the lookahead value, which is a 'char*' value (the base class
 *	holds this value, and it doesn't have any idea what kinds of items
 *	are allowed in the value stack).  So, we have to cast the 'char*'
 *	value to the appropriate type --- a pointer to a double, for this
 *	particular grammar --- and then we have to set the value.
 *
 *	Note that the lookahead value pointer should point to a location
 *	in memory that is at least as big as the largest item allowed in
 *	the value stack (e.g., it points to a union of all items allowed
 *	in the value stack).
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
void
foo::yylval(double d)
{
  char* pcLA = GetLookAheadVal();

  double* pDblVal = (double*) pcLA;

  *pDblVal = d;
}
