#ifndef NO_RCS_ID
static const char *test_cpp_RcsId = "$Id: test.cpp,v 1.3 1998/05/06 14:36:40 frodo Exp $";
#endif  /* NO_RCS_ID */

/*****************************************************************************
 * test.cpp --
 *	Test the class-based parsing machinery.
 *
 * Author --
 *	David Fletcher.
 *
 * Date --
 *	Wed Dec  3 13:44:41 1997.
 *
 * Design --
 *	Instantiate a 'foo' object and ask it to parse a file.
 *
 *****************************************************************************
 */

/******************   # d e f i n e    S t a t e m e n t s   *****************/

/************   I n c l u d e d    I n f o r m a t i o n   *******************/
#include <iostream>
#include <string.h>

#include "foo.h"

/**************    T y p e d e f ' e d    V a l u e s    *********************/

/***************    E n u m e r a t e d    T y p e s    **********************/

/*****************   C l a s s e s / S t r u c t u r e s   *******************/

/**********   O t h e r    E x t e r n a l    V a l u e s   ******************/

/**********   L o c a l l y    G l o b a l    V a l u e s   ******************/

/************************   T H E    C O D E   *******************************/

int
main(int argc, char** argv)
{
  foo f;

  int iDebug = 0;
  char* pcInputFile = 0;

  for (int i = 1; i < argc; ++i)
    {
      if (strcmp(argv[i], "debug") == 0)
	iDebug = 1;
      else
	pcInputFile = argv[i];
    }


  int iResult;

  if (pcInputFile != 0)
    iResult = f.Read(pcInputFile, iDebug);
  else
    iResult = f.Read(iDebug);

  cout << "return value: " << iResult << "\n"
       << "Last Result : " << f.GetResult() << endl;

  return iResult;
}
