#ifndef NO_RCS_ID
static const char *frodo_simple_RcsId = "$Id: Parser.cpp,v 1.3 1998/04/21 21:15:41 frodo Exp $";
#endif  /* NO_RCS_ID */

/*****************************************************************************
 * Parser.cpp --
 *	This file contains the 'simple' bison parser reworked as a C++ class.
 *
 * Author --
 *	The original bison.simple was written by Richard Stallman, whom, I
 *	believe, based his work on that of Rob Corbett.  The modifications
 *	required to turn this into a class-based parser are by David Fletcher.
 *
 * Date --
 *	Wed Apr 15 16:13:41 1998.
 *
 * Design --
 *	There are a couple of motivations for re-working the parser:
 *		- Casting the parser as a class allows us to remove the
 *		  need for the global variables that so often accompany a
 *		  yacc-compatible parser.  Bison does provide the machinery
 *		  to implement a 'pure parser', which does eliminate global
 *		  variables, so implementing the parser as a class
 *		  isn't strictly necessary.
 *
 *		- Having the parser be a class allows us to add member
 *		  functions that are particular to a parser.  For object-
 *		  oriented systems, this yields a clean, extensible design.
 *
 *	The basic approach is that there be a base class, called Parser, that
 *	implements the generic machinery for any bison-based parser.  The Parser
 *	class is an abstract base class, in that it has the parsing machinery
 *	but lacks the information to parse a specific grammar.  To recognise
 *	a particular grammar, a developer will create a class derived from
 *	the Parser base class.  Part of the definition of the derived class
 *	consists of the bison input file, which consists of the grammar
 *	specification, and the actions to take at certain points during the
 *	parse; the actions are likely to be member functions of the class
 *	derived from the Parser base class.
 *
 *	N.B.: While all of this works reasonably well with C++, this
 *	implementation still lacks some of the 'smarts' needed to make it
 *	truly work well.  In particular, the Parser base class is unaware
 *	of the data type of the items kept on the value stack.  During a
 *	shift operation, a reduce operation, or when the value stack is
 *	resized, items on the value stack are simply copied via memcpy().
 *	This is not correct, though it's benign if only pointers and numerical
 *	types are used.  What needs to happen, instead, is for the
 *	stack-handling routines to be handled so that the C++ compiler can
 *	properly invoke copy constructors, destructors, etc.
 *
 *	The changes needed to implement this are not difficult and are reasonably
 *	well contained.  Search for pValueStackCurrent to see where the
 *	stack is manipulated; also, the GrowStacks() method needs to be
 *	modified.  While these changes are simple, I've not made them yet.
 *						David Fletcher
 *						20 April, 1998
 *
 ***************************************************************************** */

/******************   # d e f i n e    S t a t e m e n t s   *****************/
#define YYTERROR	1

/************   I n c l u d e d    I n f o r m a t i o n   *******************/
// for memset()...
#include <string.h>

#include "Parser.h"

#if defined(WANT_IOSTREAMS)
# include <iostream.h>
#endif

#if defined(WANT_STDIO)
# include <stdio.h>
#endif

/**************    T y p e d e f ' e d    V a l u e s    *********************/

/***************    E n u m e r a t e d    T y p e s    **********************/

/*****************   C l a s s e s / S t r u c t u r e s   *******************/

/**********   O t h e r    E x t e r n a l    V a l u e s   ******************/

/**********   L o c a l l y    G l o b a l    V a l u e s   ******************/

/************************   T H E    C O D E   *******************************/

/*----------------------------------------------------------------------------
 * Parser::Parser()
 *	Constructor for the Parser class.
 *
 * Design --
 *	Initialise the parser to a sane state.  Note that it is up to the
 *	base class to initialise the member data (e.g., tables, size of the
 *	items in the value stack, etc) for a particular grammar...
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
Parser::Parser()
{
  Init();
}

/*----------------------------------------------------------------------------
 * Parser::~Parser()
 *	Destructor for the Parser class.
 *
 * Design --
 *	Destroy the state and value stacks, then destroy the lookahead
 *	value --- these are all that we allocated.  After that, just to
 *	make maintenance easier, re-initialise the member data to something
 *	sane.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
Parser::~Parser()
{
  delete [] pStateStackBase;
  delete [] pValueStackBase;

  delete [] pLookAheadValue;

  Init();
}

/*----------------------------------------------------------------------------
 * void
 * Parser::Init()
 *	Set all of the member data to zero's.
 *
 * Return Value --
 *	Void.
 *
 * Design --
 *	Simple.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
void
Parser::Init()
{
  uiNumErrors		= 0;
  uiTotalNumErrors	= 0;
  uiDebugOn		= 0;

  iLookAheadSymbol	= 0;
  iTranslatedSymbol	= 0;

  pLookAheadValue	= 0;

  State			= 0;
  NextState		= 0;

  uiStackSize		= 0;
  uiStackNumEntries	= 0;

  pStateStackCurrent	= 0;
  pStateStackBase	= 0;

  uiValueSize		= 0;
  pValueStackCurrent	= 0;
  pValueStackBase	= 0;

  pFirstItemIndexTbl	= 0;
  pRuleItemsTbl		= 0;
  pRuleLineInfoTbl	= 0;
  pTokenNameTbl		= 0;
  pRuleDerivesTbl	= 0;
  pLengthRhsTbl		= 0;
  pDefaultRuleTbl	= 0;
  pDefaultGotoTbl	= 0;
  pShiftOrReduceTbl	= 0;
  pShiftOrReduceGotoTbl	= 0;
  pMiscTbl		= 0;
  pBoundsTbl		= 0;

  LastState		= 0;
  TerminationState	= 0;
  FlagState		= 0;
  uiNumTokens		= 0;
}

/*----------------------------------------------------------------------------
 * char*
 * Parser::GetLookAheadVal()
 *	Get the look-ahead value, cast as a char*.
 *
 * Return Value --
 *	A non-nil char* value is returned.  The pointer is guaranteed to
 *	point to memory that is at least as big as a value stack element.
 *
 * Design --
 *	Simple.  Well, mostly simple.
 *
 *	TODO: Should the return type be a void*?
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
char*
Parser::GetLookAheadVal()
{
  return pLookAheadValue;
}

/*----------------------------------------------------------------------------
 * void
 * Parser::yyerror(const char*)
 *	Print an error message.
 *
 * Return Value --
 *	Void.
 *
 * Design --
 *	The base class doesn't do anything.  I could have made this be a
 *	pure virtual function so that derived classes were required to
 *	provide a definition for this function, but I elected to not do this.
 *	Why?  Providing a definition makes it easier to quickly build a
 *	prototype.  Those that disagree with this decision are welcome to
 *	change the code.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
void
Parser::yyerror(const char*)
{
}

/*----------------------------------------------------------------------------
 * unsigned int
 * Parser::Parse(int iDebugArg)
 *	This function, which is the equivalent of 'yyparse()' from the
 *	bison.simple file, is responsible for parsing a grammar.  All of the
 *	salient information about the grammar has been distilled down to
 *	some tables, a few other oddments, and a function [called
 *	DoReduceActions()] that contains the developer's actions to be
 *	executed at certain points during the parse.
 *
 * Return Value --
 *	The total number of errors encounted during the parse is returned.
 *
 *	N.B.: The base class does not keep track of whether the parse was
 *	successful or not; a derived class must keep track of this if it
 *	is important.  That is, errors may be encountered during a parse,
 *	but the error may have been 'innocuous,' or may not have been
 *	important because it was properly handled.  The return value will
 *	not be 0 in these cases, even though the parse was successful.
 *	If this is not appropriate for a derived class then that derived
 *	class must impose another behaviour.
 *
 * Design --
 *	Essentially, the Parse() function implements a state machine.
 *	This function manages a state stack that holds a set of states,
 *	and a value stack that holds value corresponding to each state.
 *	When a new state is encountered, that state could be shifted (pushed)
 *	onto the state stack (and the corresponding value will be
 *	shifted/pushed, too), or there may be a reduction, which means that
 *	states and values will be reduced (popped) from the stacks.  This
 *	proceeds until we reach the final state, or errors from which we
 *	cannot recover.  All of this is well-documented in a variety of
 *	places (e.g., the 'Dragon Book', the bison documentation, etc).
 *
 *	The state machine can be in one of several 'modes': getting ready
 *	to determine a new state, performing a shift, performing a reduction,
 *	or handling an error.  There is a member function that can be used
 *	to move the parser along each of these modes.  This makes the
 *	top-level function quite simple to understand: keep processing
 *	until you reach one of the modes --- eAccept or eAbort --- that
 *	indicate that the parser is finished.
 *
 *	This implementation mirrors the one provided by the bison.simple
 *	file that comes with bison.  Even though it looks quite different,
 *	this implementation is a near copy of the bison.simple implementation:
 *		- the bison.simple grammar uses goto statements within
 *		  the yyparse() function to move from mode to mode; this
 *		  implementation uses a (Parser::Action) variable to indicate
 *		  the state machine's mode;
 *
 *		- the bison.simple parser encodes the complete parser into
 *		  a single function (which most likely yields a faster
 *		  implementation); this implementation breaks the parsing
 *		  operation into the top-level loop + switch statement and
 *		  associated member functions, which I contend yields an
 *		  implementation that is easier to understand and to maintain
 *		  (with slight reduction in performance).
 *
 *	Objects of classes derived from the Parser base class are responsible
 *	---at object construction time---for initialising the tables used by
 *	the Parser::Parse() method.  That is, a classed called 'xyz' that is
 *	derived from the Parser base class, must call the TableInit() method,
 *	along with any other initalisations needed.  The TableInit() method
 *	is automatically generated by the 'parser-gen' script.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
unsigned int
Parser::Parse(int iDebugArg)
{
  uiDebugOn = (unsigned int) iDebugArg;

  //-------------------------------------------------------
  // Initialise the state information, etc.  Setting
  // iLookAheadSymbol to YYEMPTY will later cause a new
  // token to be read.
  //-------------------------------------------------------
  if (uiDebugOn)
    Message("Starting parse\n");

  uiNumErrors = 0;
  uiTotalNumErrors = 0;
  iLookAheadSymbol = YYEMPTY;

  //-------------------------------------------------------
  // Now, initialise the state and value stacks.  Then,
  // initialize the stack pointers.  Note that we make the
  // state stack pointer point to a location just prior to
  // the state stack.  In just a moment, the state stack
  // (only) will be incremented.  We resort to this
  // chicanery to keep the state stack and value stack
  // 'level' with each other.
  //-------------------------------------------------------
  CreateStacks();

  pStateStackCurrent = pStateStackBase - 1;
  pValueStackCurrent = pValueStackBase;

  //-------------------------------------------------------
  // Put the parser into the 'eNewState' state (at state 0),
  // then process until we've reached an eAccept or eAbort,
  // which are the two final conditions.
  //
  // When we're done, return the total number of errors
  // seen during the parse.
  //-------------------------------------------------------
  Parser::Action a = eNewState;
  State = 0;

  while (a != eAccept && a != eAbort)
    {
      switch (a)
	{
	 case eNewState:	a = NewState();		break;
	 case eShift:		a = Shift();		break;
	 case eReduce:		a = Reduce();		break;
	 case eNewError:	a = NewError();		break;
	 case eError:		a = ActionError();	break;
	 case ePopError:	a = ErrorPop();		break;
	 case eHandleError:	a = HandleError();	break;

	 case eAccept:
	 case eAbort:
	   break;
	}
    }

  return uiTotalNumErrors;
}

/*----------------------------------------------------------------------------
 * void Parser::CreateStacks()
 * void Parser::GrowStacks()
 *
 *	Create the state and value stacks, and the lookahead value.  Or,
 *	grow the state and value stacks.
 *
 * Return Value --
 *	Void.
 *
 * Design --
 *	The StateType value can be redefined with ease since it's typedef'd
 *	within the Parser class.  The value stack type is unknown --- all
 *	that is known is its size.
 *
 *	When growing the stacks, we simply double the size of the stacks
 *	and then copy the elements from the old stack to the new one.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
void
Parser::CreateStacks()
{
  uiStackSize = YYINITDEPTH;

  //-------------------------------------------------------
  // Create the state stack...
  //-------------------------------------------------------
  pStateStackBase = new StateType [uiStackSize];
  memset(pStateStackBase, 0, uiStackSize * sizeof(StateType));

  //-------------------------------------------------------
  // Create the value stack...
  //-------------------------------------------------------
  pValueStackBase = new char [uiStackSize * uiValueSize];
  memset(pValueStackBase, 0, uiStackSize * uiValueSize);

  //-------------------------------------------------------
  // Create the lookahead value...
  //-------------------------------------------------------
  pLookAheadValue = new char [uiValueSize];
}

void
Parser::GrowStacks()
{
  unsigned int uiOldStackSize = uiStackSize;
  uiStackSize *= 2;

  StateType* pOldStateStackBase = pStateStackBase;
  pStateStackBase = new StateType [uiStackSize];
  memset(pStateStackBase, 0, uiStackSize * sizeof(StateType));
  memcpy(pStateStackBase, pOldStateStackBase,
	 uiOldStackSize * sizeof(StateType));

  char* pOldValueStackBase = pValueStackBase;
  pValueStackBase  = new char [uiStackSize * uiValueSize];
  memset(pValueStackBase, 0, uiStackSize * uiValueSize);
  memcpy(pValueStackBase, pOldValueStackBase, uiOldStackSize * uiValueSize);

  delete [] pOldStateStackBase;
  delete [] pOldValueStackBase;
}

/*----------------------------------------------------------------------------
 * Parser::Action
 * Parser::NewState()
 *	Enter the next state, which is found in the 'State' variable.
 *	Then, determine what kind of action to take now that we've entered
 *	this state.
 *
 * Return Value --
 *	One of eNewError, eReduce, eAccept, or eShift is returned.
 *
 * Design --
 *	First, add the state to the state stack; if we run out of room,
 *	this may cause the stacks to be resized.  Then, see if entry to
 *	the new state causes a reduce or an error.
 *
 *	If the next state isn't immediately known, we have to look ahead
 *	to see what we should do.  If the look-ahead symbol is YYEMPTY,
 *	then we have to ask the Parser::yylex() function to get the next
 *	token; the lexer could return the token, which we have to translate
 *	to the internal form, or the lexer could return end-of-file.
 *
 *	Once we have the token, we can then see whether we have an error,
 *	need to reduce, or whether we should shift; the action is returned
 *	to our caller.
 *
 * Side effects --
 *	The Parser::yylex() could cause side-effects of various kinds...
 *----------------------------------------------------------------------------
 */
Parser::Action
Parser::NewState()
{
  //-------------------------------------------------------
  // Push a new state, which is found in State.  In all
  // cases, when you get here the state stack is 1 step
  // behind of the value stack, so pushing a state here
  // evens the stacks.
  //
  // Then, check to see if we need to grow the stacks.
  //-------------------------------------------------------
  *++pStateStackCurrent = State;
  ++uiStackNumEntries;

  if (uiStackNumEntries >= uiStackSize)
    {
      GrowStacks();

      pStateStackCurrent = &pStateStackBase[uiStackNumEntries];
      pValueStackCurrent = &pValueStackBase[uiStackNumEntries * uiValueSize];

      if (uiDebugOn)
	{
	  Message("Stack size increased to", uiStackSize);
	  Message("\n");
	}
    }

  if (uiDebugOn)
    {
      Message("Entering state", State);
      Message("\n");
    }

  //-------------------------------------------------------
  // Do appropriate processing given the current state.
  // Read a lookahead token if we need one and don't
  // already have one.
  //
  // First try to decide what to do without reference to
  // lookahead token.  Perhaps it's the default action?
  //-------------------------------------------------------
  NextState = pShiftOrReduceTbl[State];

  if (NextState == FlagState)
    {
      NextState = pDefaultRuleTbl[State];

      return NextState == 0 ? eNewError : eReduce;
    }

  //-------------------------------------------------------
  // The next state isn't immediately known, so get a
  // lookahead token if we don't already have one.
  //-------------------------------------------------------
  if (iLookAheadSymbol == YYEMPTY)
    {
      if (uiDebugOn)
	Message("Reading a token: ");

      iLookAheadSymbol = yylex();
    }

  //-------------------------------------------------------
  // If the look-ahead symbol <= 0 then this means we're
  // at the end of input, so we won't call Parser::Lexer()
  // anymore.  Otherwise, convert the token to its internal
  // form; we use this for indexing tables.
  //-------------------------------------------------------
  if (iLookAheadSymbol <= 0)
    {
      iTranslatedSymbol = 0;
      iLookAheadSymbol = YYEOF;

      if (uiDebugOn)
	Message("Now at end of input.\n");
    }
  else
    {
      iTranslatedSymbol = TranslateSymbol(iLookAheadSymbol);

      if (uiDebugOn)
	{
	  Message("Next token is",
		  iLookAheadSymbol, pTokenNameTbl[iTranslatedSymbol]);
	  Message("\n");
	  ShowValue(iLookAheadSymbol, pLookAheadValue);
	}
    }

  NextState += iTranslatedSymbol;

  //-------------------------------------------------------
  // See if we need to take the default action, which
  // will either be a new error or a reduction.
  //-------------------------------------------------------
  if (NextState < 0 ||
      NextState > LastState ||
      pBoundsTbl[NextState] != iTranslatedSymbol)
    {
      NextState = pDefaultRuleTbl[State];

      return NextState == 0 ? eNewError : eReduce;
    }

  //-------------------------------------------------------
  // Nope.  So, compute the 'real' NextState, which is
  // what to do for this token type in this state.  If the
  // value is:
  //	- negative, but not the most negative numer,
  //		we reduce, and -NextState is the
  //		rule number;
  //	- positive, then we shift, and NextState is the
  //		new state;
  //	- the final state then don't bother to shift; just
  //		return eAccept to indicate success;
  //	- 0, or the most negative number, then we have an
  //		error.
  //-------------------------------------------------------
  NextState = pMiscTbl[NextState];

  if (NextState < 0)
    {
      if (NextState == FlagState)
	return eNewError;

      NextState = -NextState;

      return eReduce;
    }

  if (NextState == 0)
    return eNewError;

  if (NextState == TerminationState)
    return eAccept;

  return eShift;
}

/*----------------------------------------------------------------------------
 * Parser::Action
 * Parser::Shift()
 *	We enter this routine when we want to perform a shift.  Note that the
 *	state has already been shifted onto the state stack, so this function
 *	is responsible for shifting the value onto the value stack.
 *
 * Return Value --
 *	eNewState is always returned.
 *
 * Design --
 *	The implementation is simple, but it doesn't take C++ fully into
 *	account.  That is, we shouldn't be using memcpy() to copy the look-ahead
 *	onto the value stack --- we should be using a copy constructor to do
 *	this, since this would allow developers to preserve, say, reference
 *	counts, etc.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
Parser::Action
Parser::Shift()
{
  if (uiDebugOn)
    {
      Message("Shifting token",
	      iLookAheadSymbol, pTokenNameTbl[iTranslatedSymbol]);
      Message(", ");
    }

  //-------------------------------------------------------
  // Discard the token being shifted unless it is EOF.
  // Then, copy the value onto the top of the value stack.
  // Note that uiStackNumEntries has already been incremented,
  // so we don't need to do this here.
  //
  // TODO: For C++, we really need to be smarter about how
  // we copy this.  We should invoke a virtual function
  // that 'knows' about the user's types in the stack; this
  // will let us keep reference counts up-to-date, etc.
  // For now, I'll do the easy hack...
  //-------------------------------------------------------
  if (iLookAheadSymbol != YYEOF)
    iLookAheadSymbol = YYEMPTY;

  pValueStackCurrent += uiValueSize;
  memcpy(pValueStackCurrent, pLookAheadValue, uiValueSize);

  //-------------------------------------------------------
  // If we're in an error condition (uiNumErrors > 0) then
  // this shift counts towards good behaviour.
  //-------------------------------------------------------
  if (uiNumErrors)
    uiNumErrors--;

  State = NextState;

  return eNewState;
}

/*----------------------------------------------------------------------------
 * Parser::Action
 * Parser::Reduce()
 *	This function performs a reduce operation.
 *
 * Return Value --
 *	One of eAccept, eAbort, eError, eNewError, or eNewState is returned.
 *
 * Design --
 *	First, we have to know how many elements are on the right-hand-side
 *	of the rule being reduced; we'll reduce (pop) that many elements off
 *	of the state and value stacks.  By default, the value associated with
 *	the first element on the right-hand-side of the rule is returned by
 *	the rule, so we need to extract this value before popping the items.
 *
 *	There may be a developer-defined action that needs to be performed
 *	as a result of the reduction.  These actions are all contained in
 *	the DoReduceActions() function, which is pure virtual for the Parser
 *	base class, but should be defined for classes derived from Parser.
 *	This function is automatically created by bison (and the parser-gen
 *	script) by extracting the developer-defined code from the grammar input
 *	file and re-assembling them in this function.  The function is
 *	given the next state and the current value stack, and is also given
 *	the default return value
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
Parser::Action
Parser::Reduce()
{
  //-------------------------------------------------------
  // Do a reduction.  NextState is the number of a rule
  // to reduce with.
  //
  // iLengthRHS is the number of items on the right-hand-side
  // of a rule; we have to reduce (the stacks) by this number
  // of elements.
  //
  // By default, the return value for a rule corresponds to
  // the 1st item on the right-hand-side of the rule.  We
  // extract this value now, and then allow the actions
  // associated with a rule to override this value (e.g.,
  //	{ $$ = SomeValueHere; }
  //-------------------------------------------------------
  int iLengthRHS = pLengthRhsTbl[NextState];

  char* pDefaultReturnVal = 0;

  if (iLengthRHS > 0)
    pDefaultReturnVal = &pValueStackCurrent[uiValueSize * (1 - iLengthRHS)];

  //-------------------------------------------------------
  // If debugging is on, say that we're about to reduce
  // by a rule, how many items are being reduced (popped),
  // etc.
  //-------------------------------------------------------
  if (uiDebugOn)
    {
      Message("Reducing via rule", NextState);
      Message(", line ", pRuleLineInfoTbl[NextState]);

      //-------------------------------------------------------
      // Print the symbols being reduced, and their result.
      //-------------------------------------------------------
      for (int i = pFirstItemIndexTbl[NextState]; pRuleItemsTbl[i] > 0; i++)
	Message(pTokenNameTbl[pRuleItemsTbl[i]]);

      Message(" -> ", pTokenNameTbl[pRuleDerivesTbl[NextState]]);
      Message("\n");
    }

  //-------------------------------------------------------
  // Now, call DoReduceActions(), which is defined for
  // classes derived from Parser; this function contains
  // developer-defined code to invoke for this reduction.
  // The actions could have called YYABORT, YYACCEPT, or
  // YYERROR, which are macros that cause eAccept, eAccept,
  // or eError/eNewError to be returned.  If so, then
  // we need to return to the top-level Parse() routine
  // right away.
  //-------------------------------------------------------
  Action a = DoReduceActions(NextState, pValueStackCurrent, pDefaultReturnVal);

  if (a == eAccept ||
      a == eAbort ||
      a == eError ||
      a == eNewError)
    return a;

  //-------------------------------------------------------
  // Otherwise, we need to accept the reduction, so forget
  // as many states and values as there are elements on
  // the right-hand-side of the rule.  Then, print some
  // debugging information, and then copy in the return
  // value for the rule, which is either the default value
  // we extracted above, or else is the value set by the
  // developer via the DoReduceActions() function.
  //
  // TODO: Note that we should be calling destructors
  // for the value objects we just eliminated.
  //-------------------------------------------------------
  pStateStackCurrent -= iLengthRHS;
  pValueStackCurrent -= (uiValueSize * iLengthRHS);

  uiStackNumEntries -= iLengthRHS;

  if (uiDebugOn)
    {
      StateType *ssp1 = pStateStackBase - 1;
      Message("state stack now");

      while (ssp1 != pStateStackCurrent)
	Message(" ", *++ssp1);

      Message("\n");
    }

  pValueStackCurrent += uiValueSize;

  if (pDefaultReturnVal != 0)
    memcpy(pValueStackCurrent, pDefaultReturnVal, uiValueSize);

  //-------------------------------------------------------
  // Now "shift" the result of the reduction.  Determine
  // what state that goes to, based on the state we popped
  // back to and the rule number reduced by.
  //-------------------------------------------------------
  NextState = pRuleDerivesTbl[NextState];

  State = pShiftOrReduceGotoTbl[NextState - uiNumTokens] + *pStateStackCurrent;

  if (State >= 0 &&
      State <= LastState &&
      pBoundsTbl[State] == *pStateStackCurrent)
    State = pMiscTbl[State];
  else
    State = pDefaultGotoTbl[NextState - uiNumTokens];

  return eNewState;
}

/*----------------------------------------------------------------------------
 * Parser::Action
 * Parser::NewError()
 *	We come to this function when an error is first detected.
 *
 * Return Value --
 *	eError is always returned.
 *
 * Design --
 *	The primary role of this function is to 'print' an error message,
 *	and to determine the next state.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
Parser::Action
Parser::NewError()
{
  //-------------------------------------------------------
  // We come to this function when an error is first
  // detected.  If we're already aware of the errors go
  // ahead and return right away.  Otherwise, increment
  // the overall error count, then find the next state.
  //-------------------------------------------------------
  if (uiNumErrors > 0)
    return eError;

  ++uiTotalNumErrors;

  NextState = pShiftOrReduceTbl[State];

  //-------------------------------------------------------
  // Righty ho.  Now print a little bit of information
  // about this error...
  //-------------------------------------------------------
  if (NextState <= FlagState || NextState >= LastState)
    {
      yyerror("parse error");
      return eError;
    }

  //-------------------------------------------------------
  // ... or print detailed information about the error.
  // Start x at -NextState if necessary to avoid negative
  // indexes in pBoundsTbl.
  //
  // TODO: If we used the C++ string class we wouldn't
  // have to worry about allocating space for this error
  // message, nor would we have to use strcat(), etc, to
  // construct the message.
  //-------------------------------------------------------
  int size = 0;
  char *msg;
  int x, count;

  count = 0;

  for (x = (NextState < 0 ? -NextState : 0);
       x < (int) (sizeof(pTokenNameTbl) / sizeof(char *));
       x++)
    if (pBoundsTbl[x + NextState] == x)
      size += strlen(pTokenNameTbl[x]) + 15, count++;

  msg = new char [size + 15];

  if (msg != 0)
    {
      strcpy(msg, "parse error");

      if (count < 5)
	{
	  count = 0;
	  for (x = (NextState < 0 ? -NextState : 0);
	       x < (int) (sizeof(pTokenNameTbl) / sizeof(char *));
	       x++)
	    if (pBoundsTbl[x + NextState] == x)
	      {
		strcat(msg, count == 0 ? ", expecting `" : " or `");
		strcat(msg, pTokenNameTbl[x]);
		strcat(msg, "'");
		count++;
	      }
	}

      yyerror(msg);

      delete [] msg;
    }
  else
    yyerror("parse error; also virtual memory exceeded");

  return eError;
}

/*----------------------------------------------------------------------------
 * Parser::Action
 * Parser::ActionError()
 *	We come here for an error raised explicitly by an action.
 *
 * Return Value --
 *	eAbort or eHandleError is returned.
 *
 * Design --
 *	See if we've reached our limit for tolerance of errors.  If so,
 *	then start discarding tokens.  If there are no more tokens then we
 *	have to abort the parse.
 *
 * Side effects --
 *	Headaches, gnashing of teeth, ...
 *----------------------------------------------------------------------------
 */
Parser::Action
Parser::ActionError()
{
  //-------------------------------------------------------
  // Have we reached our limit for tolerance of errors?
  // If we reach end-of-input then we've failed and
  // can't recover.  If we just tried and failed to reuse
  // the lookahead token after an error, discard it.  
  //-------------------------------------------------------
  if (uiNumErrors == 3)
    {
      if (iLookAheadSymbol == YYEOF)
	return eAbort;

      if (uiDebugOn)
	{
	  Message("Discarding token",
		  iLookAheadSymbol, pTokenNameTbl[iTranslatedSymbol]);
	  Message("\n");
	}

      iLookAheadSymbol = YYEMPTY;
    }

  //-------------------------------------------------------
  // Otherwise, we'll try to reuse lookahead token after
  // shifting the error token.
  //
  // Each real token shifted decrements uiNumErrors.
  //-------------------------------------------------------
  uiNumErrors = 3; 

  return eHandleError;
}

/*----------------------------------------------------------------------------
 * Parser::Action
 * Parser::ErrorPop()
 *	Pop the current state because it cannot handle the error token.
 *
 * Return Value --
 *	eAbort or eHandleError is returned.
 *
 * Design --
 *	Try to pop the state, but if we can't we have to abort the parse.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
Parser::Action
Parser::ErrorPop()
{
  //-------------------------------------------------------
  // Pop the current state because it cannot handle the
  // error token.  If we've popped all of the items then
  // we've nothing else to do, so we have to abort the
  // parse.
  //-------------------------------------------------------
  if (uiStackNumEntries == 0)
    return eAbort;

  pValueStackCurrent -= uiValueSize;
  State = *--pStateStackCurrent;
  --uiStackNumEntries;

  if (uiDebugOn)
    {
      StateType *ssp1 = pStateStackBase - 1;
      Message("Error: state stack now");

      while (ssp1 != pStateStackCurrent)
	Message(" ", *++ssp1);

      Message("\n");
    }

  return eHandleError;
}

/*----------------------------------------------------------------------------
 * Parser::Action
 * Parser::HandleError()
 *	We've encountered an error --- either the first or a subsequent
 *	error --- so now try to handle it.
 *
 * Return Value --
 *	ePopError, eReduce, eAccept, or eNewState is returned.
 *
 * Design --
 *	We've encountered an error and now we're in a new state.  So, see
 *	if we should pop that state (because it can't handle the error),
 *	reduce, accept the parse, or keep processing by entering a new state.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
Parser::Action
Parser::HandleError()
{
  NextState = pShiftOrReduceTbl[State];

  if (NextState == FlagState)
    return ePopError;

  NextState += YYTERROR;

  if (NextState < 0 ||
      NextState > LastState ||
      pBoundsTbl[NextState] != YYTERROR)
    return ePopError;

  NextState = pMiscTbl[NextState];

  if (NextState < 0)
    {
      if (NextState == FlagState)
	return ePopError;

      NextState = -NextState;

      return eReduce;
    }

  if (NextState == 0)
    return ePopError;

  if (NextState == TerminationState)
    return eAccept;

  if (uiDebugOn)
    Message("Shifting error token, ");

  memcpy(pValueStackCurrent, pLookAheadValue, uiValueSize);
  pValueStackCurrent += uiValueSize;

  State = NextState;

  return eNewState;
}

/*----------------------------------------------------------------------------
 * void Parser::ShowValue(int iLookAheadSymbol, const char* pLookAheadValue)
 * void Parser::Message(.....)
 *
 *	Provide the means to print information about the look-ahead
 *	symbol (token) and value.  Or, print messsages about the state of
 *	the parse.
 *
 * Return Value --
 *	Void.
 *
 * Design --
 *	The Parser base class doesn't have any idea about the look-ahead
 *	value's type, so all we can do is print the memory address.  Classes
 *	derived from the Parser base class should override this method to
 *	print something meaningful.
 *
 *	Note that the messages can be printed with stdio or iostreams.
 *
 * Side effects --
 *	None.
 *----------------------------------------------------------------------------
 */
void
Parser::ShowValue(int iLookAheadSymbol, const char* pLookAheadValue)
{
  Message("look-ahead symbol: ", iLookAheadSymbol);
  Message("look-ahead value : ", (unsigned long) pLookAheadValue);
}

void
Parser::Message(const char* pcArg1)
{
#if defined(WANT_STDIO)
  fputs(pcArg1, stderr);
#else
# if defined(WANT_IOSTREAMS)
  cerr << pcArg1;
# endif
#endif
}

void
Parser::Message(const char* pcArg1, unsigned int uiArg2)
{
#if defined(WANT_STDIO)
  fprintf(stderr, "%s %d", pcArg1, uiArg2);
#else
# if defined(WANT_IOSTREAMS)
  cerr << pcArg1 << " " << uiArg2;
# endif
#endif
}

void
Parser::Message(const char* pcArg1, int iArg2, const char* pcArg3)
{
#if defined(WANT_STDIO)
  fprintf(stderr, "%s %d %s", pcArg1, iArg2, pcArg3);
#else
# if defined(WANT_IOSTREAMS)
  cerr << pcArg1 << " " << iArg2 << " " << pcArg3;
# endif
#endif
}

void
Parser::Message(const char* pcArg1, int iArg2, short sArg3)
{
#if defined(WANT_STDIO)
  fprintf(stderr, "%s %d %d", pcArg1, iArg2, sArg3);
#else
# if defined(WANT_IOSTREAMS)
  cerr << pcArg1 << " " << iArg2 << " " << sArg3;
# endif
#endif
}

void
Parser::Message(const char* pcArg1, const char* pcArg2)
{
#if defined(WANT_STDIO)
  fprintf(stderr, "%s %s", pcArg1, pcArg2);
#else
# if defined(WANT_IOSTREAMS)
  cerr << pcArg1 << " " << pcArg2;
# endif
#endif
}
