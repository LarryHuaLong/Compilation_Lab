OVERVIEW
------------------------------------------------------------------------
Bison version 1.26 (experimental) provides the ability to create
C++-based, object-oriented parser classes.  An abstract base class,
called Parser, provides the generic parsing machinery.  A developer
wishing to create a parser class must:
	- define his/her own class derived from the Parser base class; 
	- define the grammar file, just as you would with a 'regular'
	  version of bison;
	- invoke bison with the --class-name (-c) option along with
	  the name of the derived class, which will cause bison to
	  produce the tables and code needed to specialise the generic
	  parsing machinery provided by the Parser base class;
	- compile the program so that the Parser code can be found.

See the ClassStuff subdirectory for the Parser.h and Parser.cpp files
implementing the Parser base class, and for an example that shows how
this code works.

For now, the installation process for bison (proper) does not compile
and install the Parser base class.  Thus, it is up to individual
developers to compile the code into whatever form is appropriate.  For 
individual programs, it may be appropriate to incorporate the Parser
code directly into a project.  For larger systems, it may be
appropriate to compile the code into a library, and to install that
library and the Parser.h header file into a well-known location.

I am in the process of submitting these changes to the Free Software
Foundation.  Changes to the software and installation process may be
made to better accomodate developers.



THE (TINIEST OF) DETAILS
------------------------------------------------------------------------

* Motivation

  There are a small number of parser generators that can produce
  C++-based parsers.  All have their benefits, but none quite seemed
  to suit my particular needs.  So, I set out to create something that
  would work for my situation; hopefully, what I've created is simple
  and extensible enough that others will find it useful.

* How It Works

  Most parser generators --- yacc, btyacc, bison, etc --- provide a
  generic parsing machine (usually a single function), and given an
  input file, will emit code that 'customises' the generic parser in
  order to recognise the particular grammar and take action at
  suitable points.

  I've taken a similar approach, except that the generic parsing
  machinery is provided by an abstract base class called 'Parser.'
  The implementation of the Parser base class is derived from the
  generic parser (called bison.simple) provided by bison, except that
  I have removed the use of 'goto' statements, and so on.

  Classes derived from the Parser class obtain the parsing machinery
  through inheritance.  Derived classes also provide
	- the smarts needed to recognise a particular grammar;

		An input file, usually with a .y suffix, is prepared
		in the normal way.  The contents of the .y file are no 
		different for a C++-based parser than for a C-based
		parser, except that the code in the actions can be C++ 
		code, and member functions for the derived class can
		be invoked.

		Bison is executed with the --class-name (-c) option to
		produce a set of (static) tables and 3 (protected)
		member functions for the derived class.

	- perhaps, code to be executed at certain points during the
	  parsing process.

		During the parsing process, functions may need to be
		called to perform various operations; these functions
		can be member functions of the derived (or base)
		class.
  
* Developing a Parser

  When creating a parser class, the following steps must be performed: 
	1. The derived class must be derived from the Parser base
	   class.

	2. Three functions must be declared within the derived class:

		virtual void TableInit();
		virtual int TranslateSymbol(int);
		virtual Parser::Action DoReduceActions(Parser::StateType,
						       char*, char*);

	   Bison will produce the code that defines these three
	   functions.

	3. The derived class's constructor(s) must properly initialise 
	   the parser by calling the TableInit() function.  It is
	   likely that the constructor will also initialise any
	   associated lexer(s) at this point.

	4. The yylex() member function provided by the base class must
	   be overridden.  This function is responsible for scanning
	   the input and returning tokens corresponding to the items
	   found.

	5. The yyerror() member function provided by the base class
	   should be overridden.  This function will be called when an 
	   error is encountered.  The default behaviour is to do
	   nothing.

	6. The yyparse(int) function provided by the base class is the
	   entry point.  This function is protected, and the integer
	   argument, if non-zero, tells the parser to run in 'debug
	   mode.'

	7. When the lexer needs to associate values with the tokens,
	   the look-ahead value needs to be obtained.  This can be
	   done by the GetLookAheadVal() function, which will point to
	   a location in the value stack.  Entries in the value stack
	   are defined by the %union statement in the input (.y )
	   file.


* An Example

  When developing a C++-based parser, such as the example in the
  ClassStuff directory, here are the steps that I follow:

	1. Create a header file (foo.h) that defines the derived
	   class.

		- The header file should include the Parser.h header
		  file.  E.g.,

			#include <Parser.h>

		- I tend to use flex to produce an object-oriented
		  lexer, and I follow the recommendation in the flex
		  documentation for creating uniquely-named lexers by: 

			#undef	yyFlexLexer
			#define	yyFlexLexer fooFlexLexer
			#include <FlexLexer.h>

		- Define a class derived from the Parser base class:

			class foo : public Parser

		- Define the public interface to the class:

			int Read(const char*, int);
			// etc...

		- Declare the TableInit(), TranslateSymbol(), and
		  DoReduceActions() functions as described above.

		- Declare the yylex() and yyerror() functions,
		  indicating that these will be overridden from what
		  is defined in the Parser base class.  

		- Declare the functions that the lexer can call to
		  associate values with tokens (e.g., the yylval()
		  functions).

		- I usually create the lexer as an embedded object
		  within the derived class, and the lexer may need to
		  communicate with the parser to associate values, to
		  increment the line number count, etc.  Hence, I tend 
		  to make the lexer a friend class to the derived
		  parser class.


	2. Create the implementation of the derived class (e.g.,
	   foo.cpp):

		- The definition for the class needs to be included,
		  and the tokens and value stack type definition need
		  to be included:

			#include "foo.h"
			#include "foo.tab.h"

		  Note that the 'foo.tab.h' header file is produced by 
		  bison (the --defines option should be specified when 
		  running bison).

		- The constructor definition must be sure to
		  initialise the base class, and to inform the base
		  class of the specialisations needed for this
		  particular grammar:

			foo::foo()
			  : Parser(), l() // etc....
			{
			  TableInit();
			  l.set_parser(this);
			}

		  The TableInit() function is produced by bison.

		  I've modified the FlexLexer.h header file so that it
		  keeps track of an associated parser, and I set this
		  relationship when the (derived) parser is
		  constructed.  See the FlexLexer.h header file in the 
		  ClassStuff directory.  Certainly, there are more
		  elegant ways to do this, but this approach works
		  (and requires only minimal changes to flex).

		- I eventually invoke the generic parser:

			int
			foo::Read(const char* pcInputFile, int iDebug)
			{
			  ifstream in(pcInputFile);

			  if (!in)
			    {
			      // some error message here...
			      return -1;
			    }

			  l.switch_streams(&in, &cout);

			  int iResult = Parse(iDebug == 0 ? 0 : 1);

			  return iResult;
			}

		  Note that the yyparse() function returns the number
		  of errors encountered during the parse.  It may be
		  that these errors are properly handled during the
		  parse, so a developer might choose to add a flag to
		  indicate whether a parse operation succeeded or not
		  (because the number of errors may be > 0 but the
		  parse might still be successful).

		- I implement the yylex() function, usually to invoke
		  the flex-generated lex function:

			int foo::yylex() { return l.yylex(); }

		  Occasionally, I may intercept the tokens in order to 
		  do some extra processing.

		- I implement the yyerror() function.

		- I implement a function that can be called by the
		  lexer in order to associate values with certain
		  tokens.  I tend to use the name 'yylval' for these
		  functions, and they are often overloaded, too.  All
		  of these functions use the Parser::GetLookAheadVal()
		  function to retrieve a pointer to a location in the
		  value stack:

			void
			foo::yylval(double d)
			{
			  char* pcLA = GetLookAheadVal();
			  double* pDblVal = (double*) pcLA;
			  *pDblVal = d;
			}

	3. Create the lexer input file (e.g., foo.l).

		- This file needs to include the 'complete' parser
		  definition, so it includes these files:

			#include "foo.h"
			#include "foo.tab.h"

		- When the lexer needs to communicate with the parser
		  it does something like this:

			if (pParser != 0)
			  ((foo*) pParser)->yylval(d);

		  There are more elegant ways to do this (hiding any
		  required casts) but this should serve as an
		  illustration.

		- Complete the rest of the lexer input file...

	4. Create the bison input file (e.g., foo.y).

		- The class definition for the derived class must be
		  included:

			#include "foo.h"

		  Note that bison generates the C/C++ file so that the 
		  tokens and value stack type definition are defined
		  in both the header (foo.tab.h) and source
		  (foo.tab.c) files.

		- Complete the rest of the grammar file in the
		  'normal' fashion...

	5. Compile and link into a program.

		- I put the Parser base class into a library and
		  install the header file into a well-known location.
		  This works well because I tend to have a large
		  number of parsers within the systems that I create.

CAVEATS
------------------------------------------------------------------------
There are few things to be aware of:
	1. Items on the value stack are shuffled around using
	   memcpy(), and items 'destroyed' are simply forgotten.  This 
	   is particularly bad behaviour when it comes to objects, so
	   only numerical items and pointers should be used within the 
	   %union.

	   There are ways to fix this design flaw, but I haven't taken 
	   the time to implement these fixes.  If someone wants to
	   spend the time, the best way to do this (IMO) is to provide 
	   virtual functions that can be used to create, copy, or
	   destroy items in the value stack.  This would give a
	   developer the opportunity to override the default
	   behaviour.

	2. There are a number of small steps that must be taken to
	   develop a C++, object-oriented parser with this code.  I
	   don't find these steps particularly difficult, but I do
	   wish that life were a bit simpler.  There might be ways to
	   reduce the complexity (e.g., having to remember what header 
	   files get included in which files, having to initialise the 
	   associated lexer, if any, etc).  If anyone has good ideas
	   along these lines I'd certainly like to hear them.

	3. The Parser base class is not installed into a common,
	   easily accessible location (e.g., /usr/local{lib,include}), 
	   which puts the burden on the individual developers.  Should 
	   this be changed?  What is a good, default location?  Should 
	   the name of the base class be changed from 'Parser', which
	   is awfully generic, to something less so?


CREDITS
------------------------------------------------------------------------
As stated in the bison documentation:

	Bison was written primarily by Robert Corbett; Richard
	Stallman made it Yacc-compatible.  Wilfred Hansen of Carnegie
	Mellon University added multicharacter string literals and
	other features.

These people deserve quite a lot of credit.  All I've done is to
re-assemble the bits and pieces into something that is consistent with
C++.  If you have questions, comments, suggestions for improvement,
etc, please contact:

	David Fletcher (frodo@fusionmm.com)
	303.690.4309
